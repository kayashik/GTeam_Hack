@extends('layout.default')

@section('title', 'Menu')

@section('header')
    @include('layout.header')
@endsection

@section('content')

@endsection
