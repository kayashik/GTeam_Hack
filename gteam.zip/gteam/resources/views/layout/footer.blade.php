
<div class="container-fluid footer">
    <div class="copyright sm-text-center p-t-14 p-b-14">
        <hr>
        <p class="small no-margin pull-left sm-pull-reset">
            <span class="hint-text"><span class="font-additional">{{ config('app.name') }}</span>&nbsp;©&nbsp;{{ date('Y') }}</span>
        </p>
        <p class="small no-margin pull-right sm-pull-reset">
            <span class="hint-text">Made by GTeam ®</span>
        </p>
        <div class="clearfix"></div>
    </div>
</div>
