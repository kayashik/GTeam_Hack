<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="{{route('admin.menu')}}"><img style="max-height: 50px" src="{{ assert('img/DS2017_TP09_black.png') }}" alt=""></a>
        </div>
        <ul class="nav navbar-nav">
            <li><a href="#">Add user</a></li>
            <li><a href="#">Exit</a></li>
        </ul>
    </div>
</nav>